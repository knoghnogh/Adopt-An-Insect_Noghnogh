﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_An_Ant_By_KALED_NOGHNOGH
{
    class Habitate
    {
        public string Landscape;
        public string Temperature;

        public void Play()
        { 
        
        }

    }
}
