﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adopt_An_Ant_By_KALED_NOGHNOGH
{
    class Player
    {
        public string Name;  
        public Boolean Size;
        public string Color;

        public void Play() { }
    
    }
}
