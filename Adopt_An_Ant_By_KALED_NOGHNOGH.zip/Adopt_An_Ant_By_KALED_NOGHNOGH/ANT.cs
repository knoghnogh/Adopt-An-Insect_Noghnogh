﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Adopt_An_Ant_By_KALED_NOGHNOGH
{
    class ANT
    {
        //fields
        public double Birthdate;
        public int Legs;
        public bool Color;

        public ANT() 
        {
            Console.WriteLine("New Ant " + Name + " has Appeared");
            Console.ReadKey();
        }

        //constructor
        public string Name;

        public void Lift() 
        {
            Console.WriteLine("How much will it lift?");
        }
        
        public void Climb() 
        {
            Console.WriteLine("Where does it climb?");
        }
        
        public void Walk() 
        {
            Console.WriteLine("Where should it walk?");
        }

    }

}
